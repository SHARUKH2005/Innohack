import { AuthCard } from "@/components/auth/auth-card";

export default function SignUpPage() {
  return <AuthCard initialMode="register" redirectUrl="/dashboard" />;
}