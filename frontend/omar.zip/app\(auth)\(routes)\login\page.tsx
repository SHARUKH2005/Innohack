import { AuthCard } from "@/components/auth/auth-card";

export default function LoginPage() {
  return <AuthCard initialMode="login" redirectUrl="/dashboard" />;
}
